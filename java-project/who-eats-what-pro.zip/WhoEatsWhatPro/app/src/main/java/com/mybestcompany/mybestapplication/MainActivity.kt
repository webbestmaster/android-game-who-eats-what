package com.mybestcompany.mybestapplication

//import com.google.android.gms.ads.MobileAds
import android.annotation.SuppressLint
import android.media.AudioManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
//import com.google.android.gms.ads.AdRequest
//import com.google.android.gms.ads.AdView
//import com.google.android.gms.ads.RequestConfiguration
//import com.google.android.gms.ads.interstitial.InterstitialAd
//import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import android.util.Log
import android.webkit.WebChromeClient
import androidx.appcompat.app.AppCompatDelegate

//import com.google.android.gms.ads.*

const val interstitialId = "ca-app-pub-6654692173920232/7751752577"

class MainActivity : AppCompatActivity() {
    //    private var mInterstitialAd: InterstitialAd? = null
    private var myAdTag = "MY_AD_TAG"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.activity_main)

        webViewSetup()

//        setupAd()
//        bannerAdSetup()
//        interstitialAdLoad()
    }

/*
    private fun setupAd() {
        MobileAds.initialize(this) {}

        val adRequestConfiguration: RequestConfiguration = RequestConfiguration
            .Builder()
            .build()

        MobileAds.setRequestConfiguration(adRequestConfiguration)
    }
*/

/*
    private fun interstitialAdLoad() {
        val adRequest = AdRequest
            .Builder()
            .build()

        InterstitialAd.load(
            this,
            interstitialId,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.d(myAdTag, adError.message)

                    val error =
                        "domain: ${adError.domain}, code: ${adError.code}, message: ${adError.message}"

//                    Toast.makeText(
//                        this@MainActivity,
//                        "onAdFailedToLoad() with error $error",
//                        Toast.LENGTH_SHORT
//                    ).show()

                    mInterstitialAd = null
                }

                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    Log.d(myAdTag, "Ad was loaded.")

//                    Toast.makeText(this@MainActivity, "onAdLoaded()", Toast.LENGTH_SHORT).show()

                    mInterstitialAd = interstitialAd
                }
            }
        )
    }

    // Show the ad if it's ready. Otherwise toast and restart the game.
    private fun showInterstitial() {
        if (mInterstitialAd != null) {

            mInterstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(myAdTag, "Ad was dismissed / closed")

//                    Toast
//                        .makeText(baseContext, "Ad was dismissed / closed", Toast.LENGTH_SHORT)
//                        .show()

                    mInterstitialAd = null

                    interstitialAdLoad()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError?) {
                    Log.d(myAdTag, "Ad failed to show")

//                    Toast.makeText(baseContext, "Ad failed to show", Toast.LENGTH_SHORT).show()

                    mInterstitialAd = null

                    interstitialAdLoad()
                }

                override fun onAdShowedFullScreenContent() {
                    Log.d(myAdTag, "Ad showed fullscreen content")

//                    Toast
//                        .makeText(baseContext, "Ad showed fullscreen content", Toast.LENGTH_SHORT)
//                        .show()
                }
            }

            mInterstitialAd?.show(this)
            return
        }

//        Toast.makeText(this, "Ad wasn't loaded", Toast.LENGTH_SHORT).show()

        interstitialAdLoad()
    }
*/

/*
    private fun bannerAdSetup() {
        val adView: AdView = findViewById(R.id.adView)
        val adRequest = AdRequest.Builder().build()

        adView.loadAd(adRequest)
    }
*/

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun webViewSetup() {
        val wbWebView: WebView = findViewById(R.id.wbWebView)

        wbWebView.webViewClient = WebViewClient()
        wbWebView.webChromeClient = WebChromeClient()

//        wbWebView.addJavascriptInterface(this, "Android")

        volumeControlStream = AudioManager.STREAM_MUSIC

        // https://developer.android.com/reference/android/webkit/WebSettings#getMediaPlaybackRequiresUserGesture()
        wbWebView.apply {
            settings.javaScriptEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.loadsImagesAutomatically = true
            loadUrl("file:///android_asset/dist/index.html")
        }
    }

/*
    @JavascriptInterface
    fun displayInterstitial() {
        messageHandler.sendEmptyMessage(0)
    }
*/

    @JavascriptInterface
    fun onAppLoaded() {
        val wbWebView: WebView = findViewById(R.id.wbWebView)
        wbWebView.setAlpha(1f);
    }

/*
    @SuppressLint("HandlerLeak")
    private val messageHandler: Handler = object : Handler() {
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            showInterstitial()
        }
    }
*/

    private var backButtonPressedTimeStamp: Long = 0

    override fun onBackPressed() {
        val wbWebView: WebView = findViewById(R.id.wbWebView)

        if (wbWebView.canGoBack()) {
            wbWebView.goBack()
            return
        }

        if (backButtonPressedTimeStamp + 2000 > System.currentTimeMillis()) {
            super.onBackPressed()
        } else {
            Toast.makeText(baseContext, "Press again to exit", Toast.LENGTH_SHORT).show()
        }

        backButtonPressedTimeStamp = System.currentTimeMillis()
    }

    override fun onPause() {
        val wbWebView: WebView = findViewById(R.id.wbWebView)
        wbWebView.onPause();

        wbWebView.evaluateJavascript("window.dispatchEvent(new Event('appPause'));", null);

        super.onPause();
    }

    override fun onResume() {
        val wbWebView: WebView = findViewById(R.id.wbWebView)
        wbWebView.onResume();

        wbWebView.evaluateJavascript("window.dispatchEvent(new Event('appResume'));", null);

        super.onResume();
    }
}
